import pygame
import settings

class player(pygame.sprite.Sprite):
    def __init__(self,game,x,y,color):
        self.x = x
        self.y = y
        self.color = color
        self.game = game
        self.falling = True

        super().__init__()

        self.image = pygame.Surface([25,32])
        self.image.fill(self.color)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    def move(self, direction, distance):
        if direction == 0:
            self.rect.x += distance
        elif direction == 1:
            self.rect.x -= distance
        elif direction == 2:
            self.rect.y += distance
        elif direction == 3:
            self.rect.y -= distance
    
    def update(self):
        if self.falling:
            self.rect.y += 1
        gamegroup = pygame.sprite.groupcollide(self.game.playersprites,self.game.GameMap,False,False)
        if gamegroup: # Collision?
            self.rect.y -=1
            for blk in gamegroup:
                if self.rect.bottom > blk.rect.top:
                    self.rect.bottom = blk.rect.bottom
                    self.falling = False
        else:
            self.falling = True

