import pygame
import settings

class Block(pygame.sprite.Sprite):
    def __init__(self,x,y,tilepath):
        self.x = x
        self.y = y
        self.tilepath = tilepath
        
        super().__init__()
        
        self.image = pygame.image.load(self.tilepath).convert_alpha()
       
        self.rect = self.image.get_rect()
                      
        colorImage = pygame.Surface(self.image.get_size()).convert_alpha()
        
        self.rect.x=self.x
        self.rect.y=self.y
        