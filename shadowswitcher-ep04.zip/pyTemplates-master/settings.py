# Game Options and Settings
TITLE = "TITLE"
SCREEN_WIDTH = 1300
SCREEN_HEIGHT = 800
FPS = 60

# Define Colours
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

BL_WIDTH = 32
BL_HEIGHT = 32