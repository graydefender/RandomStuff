import pygame as pg 
from pygame.locals import *
import random
import settings
import game
import block
import player

class Game:
    def __init__(self):
        # Initialise game code
        pg.init()
        pg.mixer.init()
        self.screen = pg.display.set_mode((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))
    
        pg.display.set_caption(settings.TITLE)
        self.clock = pg.time.Clock()
        self.running = True
        self.direction = 0
        self.directionB4 = 0
        self.directionDownCounter = 0
        self.distanceToTravel = 0.5

        self.laserCoolDown = 0
        self.canIShootAtLaser = True
        self.PlatFormTile:block
 
        
    def new(self):
        # Starts a new game
        self.allSprites = pg.sprite.Group()
        self.GameMap = pg.sprite.Group()
        self.playersprites = pg.sprite.Group()
        
        self.readlevel()
        self.player = player.player(self,100,600,settings.BLUE)
        self.playersprites.add(self.player)

                
        self.run()

    def run(self):
        # Game Loop Code
        self.playing = True
        while self.playing:
            self.clock.tick(settings.FPS)
            self.events()
            self.update()
            self.GameMap.draw(self.screen)
            
            self.draw()

    def update(self):
        self.playersprites.update()    

    def events(self):
        # Game Loop Events handler
        for event in pg.event.get():
            # check for closing the window
            if event.type == pg.QUIT:
                if self.playing:
                    self.playing = False
                self.running = False

        keys = pg.key.get_pressed()
        if keys[K_LEFT]:
            self.player.move(1,2)
        if keys[K_RIGHT]:
            self.player.move(0,2)
        if keys[K_UP]:
            self.player.move(3,2)
        if keys[K_DOWN]:
            self.player.move(2,2)



    def draw(self):
        # Game Loop draw screen
        self.screen.fill(settings.GREEN)        
        self.GameMap.draw(self.screen)
       # self.player.draw(self.screen)   
        self.playersprites.draw(self.screen)
            
        # After redrawing the screen, flip it
        pg.display.flip()

    def showStartScreen(self):
        # Show the start screen of the game
        pass

    def showGameOverScreen(self):
        # show the Game over screen
        pass

    def readlevel(self):
        wallx:int
        wally:int
        file1 = open("map01.bin", "rb")
        text=file1.read()
        file1.close()  # to change file access modes
             
        wally=0
        wallx=0
        for y in range(25):
            wallx=0
            for x in range(40):                         
                value = text[y*40+x]
                if value!=0:
                    if value == 5:
                        tile="assets/ladder.jpg"
                    else:
                        tile="assets/brick1t2.png"
                    PlatformTile = block.Block(wallx,wally,tile)
                    self.GameMap.add(PlatformTile)                
                wallx+=32
            wally+=32
   
            